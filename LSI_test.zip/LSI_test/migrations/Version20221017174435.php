<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20221017174435 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE SEQUENCE exports_id_seq INCREMENT BY 1 MINVALUE 1 START 1');
        $this->addSql('CREATE TABLE exports (id SERIAL , name VARCHAR(100) NOT NULL, datetime TIMESTAMP(0) WITHOUT TIME ZONE DEFAULT NULL, username VARCHAR(100) NOT NULL, premises VARCHAR(100) NOT NULL, PRIMARY KEY(id))'); 
        $this->addSql("INSERT INTO exports (id, name,datetime , username, premises) VALUES (1, 'export1', '2022-10-01 12:00:00', 'user1','local1'),(2,'export2', '2022-10-02 10:00:00', 'user3','local2'),(3,'export3', '2022-10-03 12:00:00', 'user1','local2'),(4, 'export4', '2022-10-01 12:00:00', 'user2','local3'),(5, 'export5', '2022-10-05 02:00:00', 'user1','local1')"); 
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE SCHEMA public');
        $this->addSql('DROP SEQUENCE exports_id_seq CASCADE');
        $this->addSql('DROP TABLE exports');
    }
}
