<?php

namespace App\Repository;

use App\Entity\Exports;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Exports>
 *
 * @method Exports|null find($id, $lockMode = null, $lockVersion = null)
 * @method Exports|null findOneBy(array $criteria, array $orderBy = null)
 * @method Exports[]    findAll()
 * @method Exports[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ExportsRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Exports::class);
    }

    /**
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function add(Exports $entity, bool $flush = true): void
    {
        $this->_em->persist($entity);
        if ($flush) {
            $this->_em->flush();
        }
    }

    /**
     * @throws ORMException
     * @throws OptimisticLockException
     */
    public function remove(Exports $entity, bool $flush = true): void
    {
        $this->_em->remove($entity);
        if ($flush) {
            $this->_em->flush();
        }
    }

    public function getExports($conditions='')
    {
        $where_premis='where 1=1';
        $where_date='';
        if($conditions!=''){
            $premises=$conditions["premises"];
            if($premises!='') 
                $where_premis="where premises='$premises'";
            $fromdate=date('Y-m-d', strtotime($conditions["from_date"]));
            $todate=date('Y-m-d', strtotime($conditions["to_date"]));
            if($conditions["from_date"]!='' and  $conditions["to_date"]!='')
                $where_date="and datetime::date between '$fromdate' and '$todate' ";
        }
        $conn = $this->getEntityManager()->getConnection();
        $sql = "SELECT * FROM exports $where_premis $where_date";    
        return $conn->fetchAllAssociative($sql);
    }

    public function getPremisis()
    {
        $conn = $this->getEntityManager()->getConnection();
        $sql = "SELECT string_agg(DISTINCT premises, ',') all_premises FROM exports"; 
        return $conn->fetchAssociative($sql);
    }
 

    // /**
    //  * @return Exports[] Returns an array of Exports objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('e.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Exports
    {
        return $this->createQueryBuilder('e')
            ->andWhere('e.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
