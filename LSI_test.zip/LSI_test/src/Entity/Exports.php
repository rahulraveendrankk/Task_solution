<?php

namespace App\Entity;

use App\Repository\ExportsRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ExportsRepository::class)]
class Exports
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 100, unique: true)]
    private $name;

    #[ORM\Column(type: 'datetime',  nullable: true)]
    private $datetime; 

    #[ORM\Column(type: 'string', length: 100, unique: true)]
    private $username;

    #[ORM\Column(type: 'string', length: 100, unique: true)]
    private $premises;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function getDatetime(): ?string
    {
        return $this->datetime;
    }

    public function getUsername(): ?string
    {
        return $this->username;
    }

    public function getPremises(): ?string
    {
        return $this->premises;
    }
}
