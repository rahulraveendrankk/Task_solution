<?php

namespace App\Controller;

use App\Entity\Exports;
use App\Repository\ExportsRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ExportsController extends AbstractController
{
    #[Route('/exports', name: 'app_exports')]
    public function index(ExportsRepository $er): Response
    { 

        $exports= $premises=  array();
        $post_data='';
        // try{
            if(isset($_POST) and !empty($_POST)){   
                $post_data=$_POST;
            } 
            $exports =  $er->getExports($post_data);
            foreach($exports as $key => $value){
                $exports[$key]['date']=date('Y-m-d',strtotime($value['datetime']));
                $exports[$key]['time']=date('H:i:s',strtotime($value['datetime']));
            }
            //   echo "<pre>";print_r($_POST);die;
            
            $premises_str= $er->getPremisis();
            
            if(isset($premises_str['all_premises']))
                $premises = explode(',', $premises_str['all_premises']); 
            else
                $premises = array();
        // }catch(\Exception $e){
        //     echo 'Caught exception: ',  $e->getMessage(), "\n";die;
           
        // }
        
        return $this->render('exports/index.html.twig', [ 
            'premises' => $premises,
            'exports' => $exports,
            'post_data'=>$post_data

        ]);
    }
}
