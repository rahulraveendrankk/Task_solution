I have completed the the task as given discription.

Technologies:
  
    PHP 8.0.1
    Symfony 5
    Posgresql
    Doctrine 
    HTML and CSS

Please use migration versions to import Tables and test data.
In report datas are fetched according to filters.